package com.cg.capbook.beans;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name="seq2", initialValue=1, allocationSize=100)
public class FriendRequest {
@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq2")
private int id2;
private int requestId;
@ManyToOne
@JoinColumn(name="userId")
private User user;
public FriendRequest(int requestId, User user) {
	super();
	this.requestId = requestId;
	this.user = user;
}
public int getRequestId() {
	return requestId;
}
public void setRequestId(int requestId) {
	this.requestId = requestId;
}
public User getUser() {
	return user;
}
public void setUser(User user) {
	this.user = user;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + requestId;
	result = prime * result + ((user == null) ? 0 : user.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	FriendRequest other = (FriendRequest) obj;
	if (requestId != other.requestId)
		return false;
	if (user == null) {
		if (other.user != null)
			return false;
	} else if (!user.equals(other.user))
		return false;
	return true;
}
@Override
public String toString() {
	return "FriendRequest [requestId=" + requestId + ", user=" + user + "]";
}
public FriendRequest() {
	super();
}}

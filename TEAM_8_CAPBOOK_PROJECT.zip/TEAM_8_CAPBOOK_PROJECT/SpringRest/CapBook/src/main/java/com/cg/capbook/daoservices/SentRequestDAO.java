package com.cg.capbook.daoservices;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import com.cg.capbook.beans.SentRequest;

public interface SentRequestDAO extends JpaRepository<SentRequest, Integer> {

	@Transactional
	@Modifying
	@Query(value="INSERT INTO Sent_request(sent_request_id,user_id) VALUES(?1,?2)",nativeQuery=true)
	int saveSentRequest(int userIdSender,int userIdreceiver);
	
//	@Query("UPDATE SentRequest a SET a.sentRequestId=:userIdreceiver WHERE a.user.userId=:userIdSender")
    @Transactional
	@Modifying
	@Query("DELETE FROM SentRequest a WHERE a.sentRequestId=:userIdreceiver and a.user.userId=:userIdSender")
	int cancelRequestSent(@Param("userIdSender")int userIdSender, @Param("userIdreceiver") int userIdreceiver);

}

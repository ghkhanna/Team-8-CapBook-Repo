import { Address } from "./address";

export interface EditUser {
	userId:number,
	emailId:string,
    firstName:string,
	lastName:string,
	address:Address
}
 




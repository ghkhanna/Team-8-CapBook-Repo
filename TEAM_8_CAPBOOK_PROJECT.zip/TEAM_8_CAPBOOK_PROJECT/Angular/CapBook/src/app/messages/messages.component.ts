import { Component, OnInit } from '@angular/core';
import { User } from '../user'
import { UserService } from '../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Message } from '../message';
import { Time } from '@angular/common';

@Component({
  selector: 'app-messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.css']
})
export class MessagesComponent implements OnInit {

  constructor(private userService:UserService, private route:ActivatedRoute,private router:Router) {
    this._SendMessage="";
   }
  users:User[];
  user:User;
  errorMessage:string;
  userIdSenderSentMessages:number;
  userIdreceiverSentMessages:number;
  userIdreceiverReceivedMessages:number;
  userIdSenderReceivedMessages:number;
  message:Message;
  messagesSent:Message[];
  messagesReceived:Message[];
  firstName:string
  lastName:string
  senderName:string
  successMessage:string
  _SendMessage:string=''


  ngOnInit() {
    this.user=JSON.parse(localStorage.getItem("user"));
    const id = this.route.snapshot.paramMap.get('id');
    this.userIdreceiverSentMessages= +id;
    this.userIdSenderSentMessages=this.user.userId;
    this.firstName=this.user.firstName
    this.lastName=this.user.lastName 
    this.userIdreceiverReceivedMessages=this.user.userId;
    this.senderName = this.firstName + this.lastName;
    this.userService.getSentMessages(this.userIdSenderSentMessages).subscribe(
      tempMessages=>{
        this.messagesSent=tempMessages;
        console.log(this.messagesSent);
      },
      error=>{
        this.errorMessage=error;
      }
    )
    this.userService.getReceivedMessages(this.userIdreceiverReceivedMessages).subscribe(
      tempMessages=>{
        this.messagesReceived=tempMessages;
        console.log(this.messagesReceived)
      },
      error=>{
        this.errorMessage=error;
      }
    )
    
  }
  get sendMessage() : string {
    return this._SendMessage
  }
 set sendMessage(value : string) {
    this._SendMessage = value;
  }
  
  
  sendMessageToUser(userIdSender:number,userIdreceiver:number, message:string){
    this.userService.sendMessage(userIdSender,userIdreceiver, message).subscribe(
      successMessage=>{
        this.successMessage=successMessage
      },
      errorMessage=>{
        this.errorMessage=errorMessage
      }
    )
  }

}
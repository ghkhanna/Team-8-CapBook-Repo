import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { HttpClient } from '@angular/common/http';
import { UserService } from '../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  user:User
  errorMessage:string
  constructor(private http:HttpClient,private userServices:UserService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit() {
    this.user=JSON.parse(localStorage.getItem("user"))
    this.userServices.getUser(this.user.emailId).subscribe(
      user=>{
        this.user=user
      },
      message=>{
        this.errorMessage=message
      }

    )
  }

}

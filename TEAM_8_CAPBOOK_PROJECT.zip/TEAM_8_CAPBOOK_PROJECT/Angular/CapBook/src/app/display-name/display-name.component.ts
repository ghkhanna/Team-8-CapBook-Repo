import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../services/user.service';
import { User } from '../user';

@Component({
  selector: 'app-display-name',
  templateUrl: './display-name.component.html',
  styleUrls: ['./display-name.component.css']
})
export class DisplayNameComponent implements OnInit {

  constructor(private router:Router,private userServices : UserService,private route:ActivatedRoute) { }
  user:User;
  errorMessage:string;
  userIdSender:number

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    const userIdSender=+id;
    this.userServices.getUserDetails(userIdSender).subscribe(
        tempUser=>{
          this.user=tempUser;
        },
        error=>{
          this.errorMessage=error
        }
    )
  }

  displayName(id:number){
    this.userIdSender=id
    this.userServices.getUserDetails(this.userIdSender).subscribe(
      tempUser=>{
        this.user=tempUser;
      },
      error=>{
        this.errorMessage=error
      }
  )
  }


}

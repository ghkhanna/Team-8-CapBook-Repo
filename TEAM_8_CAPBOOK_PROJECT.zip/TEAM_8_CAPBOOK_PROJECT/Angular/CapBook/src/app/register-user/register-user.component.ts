import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import {ActivatedRoute,Router} from '@angular/router';
import { User } from '../user';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms'
import {ErrorStateMatcher} from '@angular/material/core';


@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

  pageTitle: string = "Create a new account today"
  pageDescription: string ="It's free and always will be!"
  successMessage:string
  errorMessage:string
  registerForm:FormGroup
  angForm:FormGroup

  constructor(private fb: FormBuilder, private router:Router,private userService : UserService) {
    this.createForm()
   }
  

  ngOnInit() {
    
  }
  
  createForm(){
    this.angForm=this.fb.group({
      name: ['', Validators.required]
    })
  }

  onSubmit(user:User){
console.log(user);
    this.userService.registerUser(user).subscribe(
      message=>{
        this.successMessage=message
      },
      message=>{
        this.errorMessage='haha! you are screwed'
//        this.errorMessage=message
      }
    )
    this.router.navigate(['/login'])
  }
}
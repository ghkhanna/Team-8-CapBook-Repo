import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MessagesReceivedComponent } from './messages-received.component';

describe('MessagesReceivedComponent', () => {
  let component: MessagesReceivedComponent;
  let fixture: ComponentFixture<MessagesReceivedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MessagesReceivedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MessagesReceivedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

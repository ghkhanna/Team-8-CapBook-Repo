import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';

import { User } from '../user';
import { Message } from '../message';

@Component({
  selector: 'app-messages-received',
  templateUrl: './messages-received.component.html',
  styleUrls: ['./messages-received.component.css']
})
export class MessagesReceivedComponent implements OnInit {

  constructor(private userService:UserService, private route:ActivatedRoute,private router:Router) { }
  userIdreceiver:number
  userReceiver:string
  messagesReceived:Message[];
  errorMessage:string;
  userIdSender:number
  userIdSenders:number[]
  users:User[];
  user:User;
  users_senders:User[]
  
  ngOnInit() {
    var i:number=0
    this.user=JSON.parse(localStorage.getItem("user"));
    // this.userService.getUserDetails()
    this.userIdreceiver=this.user.userId
    this.userService.getReceivedMessages(this.userIdreceiver).subscribe(
      tempMessage=>{
        this.messagesReceived=tempMessage
        // this.messagesReceived.forEach(messageReceived => {
        //   this.userIdSenders[i]=messageReceived.userIdSender
        //   console.log(this.userIdSenders[i])
          
        //   this.userService.getUserDetails(this.userIdSenders[i]).subscribe(
        //     user=>{
        //       this.users_senders[i]=user
        //   },
        //     ()=>{console.log("Error segment");
        //     }
        //   ),   
        //   i++
        // })
        // console.log(this.messagesReceived)
      },
      error=>{
        this.errorMessage=error;
      }
    )
  }

}